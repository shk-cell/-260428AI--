// ═══════════════════════════════════════════════════
//  SNAKE.IO — 방(Room) 기반 멀티플레이어 서버
//  교사가 방을 만들고 시작 → 제한시간 → 최종 랭킹
// ═══════════════════════════════════════════════════
const http = require('http');
const fs   = require('fs');
const path = require('path');
const os   = require('os');
const { WebSocketServer, WebSocket } = require('ws');

// ── 설정 ──
const PORT      = 3000;
const WORLD_W   = 3000;
const WORLD_H   = 3000;
const TICK_MS   = 45;
const MAX_FOOD  = 1800;
const SEG_GAP   = 6;
const BASE_SPD  = 3.0;
const BOOST_SPD = 5.5;
const GROW_PER_FOOD = 2;

// 서버 시작 시 선생님 비밀번호 무작위 생성
const TEACHER_PW = String(Math.floor(1000 + Math.random() * 9000)); // 4자리 숫자

// ── 전역 상태 ──
const rooms     = new Map(); // code → room
const wsInfo    = new Map(); // ws → { id, roomCode }
let   nextId    = 1;

// ── HTTP 서버 ──
const httpServer = http.createServer((req, res) => {
  let filePath = path.join(__dirname, req.url === '/' ? 'index.html' : req.url);
  fs.readFile(filePath, (err, data) => {
    if (err) { res.writeHead(404); res.end('Not found'); return; }
    const ext  = path.extname(filePath);
    const mime = { '.html': 'text/html', '.js': 'application/javascript' }[ext] || 'text/plain';
    res.writeHead(200, { 'Content-Type': mime });
    res.end(data);
  });
});

// ── WebSocket 서버 ──
const wss = new WebSocketServer({ server: httpServer });

wss.on('connection', (ws) => {
  const id = nextId++;
  wsInfo.set(ws, { id, roomCode: null });
  send(ws, { type: 'init', id });

  ws.on('message', (raw) => {
    try { handleMsg(ws, JSON.parse(raw)); } catch (e) {}
  });

  ws.on('close', () => {
    const info = wsInfo.get(ws);
    if (info && info.roomCode) {
      const room = rooms.get(info.roomCode);
      if (room) handleLeave(room, info.id);
    }
    wsInfo.delete(ws);
  });
});

// ── 메시지 처리 ──
function handleMsg(ws, msg) {
  const info = wsInfo.get(ws);
  if (!info) return;

  // ── 방 없이 처리 ──
  if (msg.type === 'getRooms') {
    const list = Array.from(rooms.values())
      .filter(r => r.phase === 'lobby')
      .map(r => ({ code: r.code, teacherName: r.teacherName, count: r.players.size }));
    send(ws, { type: 'roomList', rooms: list });
    return;
  }

  if (msg.type === 'createRoom') {
    if (msg.password !== TEACHER_PW) {
      send(ws, { type: 'err', msg: '비밀번호가 틀렸습니다.' }); return;
    }
    if (info.roomCode) { send(ws, { type: 'err', msg: '이미 방에 있습니다.' }); return; }
    const name     = String(msg.name || '선생님').slice(0, 10).trim() || '선생님';
    const duration = [60, 120, 180, 300].includes(Number(msg.duration)) ? Number(msg.duration) : 180;
    const code     = makeCode();
    const room = {
      code, teacherName: name, teacher: info.id,
      phase: 'lobby',       // lobby | countdown | playing | ended
      duration,
      players: new Map(),   // id → { id, ws, name, isTeacher }
      gs: null,             // game state (playing phase)
      gameLoop: null, cdTimer: null,
      foodId: 1,
      foods: new Map(),
      newFoods: [],
    };
    room.players.set(info.id, { id: info.id, ws, name, isTeacher: true });
    rooms.set(code, room);
    info.roomCode = code;
    send(ws, { type: 'roomCreated', code, duration });
    return;
  }

  if (msg.type === 'joinRoom') {
    const code = String(msg.code || '').toUpperCase().trim();
    const room = rooms.get(code);
    if (!room)                    { send(ws, { type: 'err', msg: '방을 찾을 수 없습니다.' }); return; }
    if (room.phase !== 'lobby')   { send(ws, { type: 'err', msg: '이미 게임이 시작됐습니다.' }); return; }
    if (info.roomCode)            { send(ws, { type: 'err', msg: '이미 방에 있습니다.' }); return; }
    const name = String(msg.name || 'Player').slice(0, 10).trim() || ('P' + info.id);
    room.players.set(info.id, { id: info.id, ws, name, isTeacher: false });
    info.roomCode = code;
    send(ws, { type: 'roomJoined', code, duration: room.duration });
    broadcastLobbyUpdate(room);
    return;
  }

  // ── 방 안에서 처리 ──
  if (!info.roomCode) return;
  const room = rooms.get(info.roomCode);
  if (!room) return;

  if (msg.type === 'startGame') {
    if (room.teacher !== info.id) return;
    if (room.phase !== 'lobby') return;
    if (room.players.size < 1) { send(ws, { type: 'err', msg: '참여자가 없습니다.' }); return; }
    startCountdown(room);
    return;
  }

  if (msg.type === 'resetRoom') {
    if (room.teacher !== info.id) return;
    if (room.gameLoop) { clearInterval(room.gameLoop); room.gameLoop = null; }
    if (room.cdTimer)  { clearInterval(room.cdTimer);  room.cdTimer  = null; }
    room.phase    = 'lobby';
    room.gs       = null;
    room.foods    = new Map();
    room.newFoods = [];
    broadcastRoom(room, { type: 'backToLobby' });
    broadcastLobbyUpdate(room);
    return;
  }

  if (msg.type === 'input') {
    if (!room.gs) return;
    const gp = room.gs.players.get(info.id);
    if (!gp || !gp.alive) return;
    gp.targetAngle = Number(msg.angle) || 0;
    gp.boosting    = !!msg.boost && gp.targetLen > 10;
    return;
  }
}

// ── 퇴장 처리 ──
function handleLeave(room, id) {
  const wasTeacher = (room.teacher === id);

  // 게임 중이면 게임 플레이어도 처리
  if (room.gs) {
    const gp = room.gs.players.get(id);
    if (gp) gp.alive = false;
  }

  room.players.delete(id);
  broadcastRoom(room, { type: 'playerLeave', id });

  if (wasTeacher) {
    // 선생님이 나가면 방 종료
    if (room.gameLoop)  clearInterval(room.gameLoop);
    if (room.cdTimer)   clearInterval(room.cdTimer);
    broadcastRoom(room, { type: 'err', msg: '선생님이 퇴장하여 방이 닫혔습니다.' });
    rooms.delete(room.code);
  } else {
    if (room.phase === 'lobby') broadcastLobbyUpdate(room);
  }
}

// ═══════════════════════════════════════════════════
//  게임 흐름
// ═══════════════════════════════════════════════════

function startCountdown(room) {
  room.phase = 'countdown';
  let n = 3;
  broadcastRoom(room, { type: 'countdown', n });
  room.cdTimer = setInterval(() => {
    n--;
    if (n > 0) {
      broadcastRoom(room, { type: 'countdown', n });
    } else {
      clearInterval(room.cdTimer);
      room.cdTimer = null;
      beginGame(room);
    }
  }, 1000);
}

function beginGame(room) {
  room.phase    = 'playing';
  room.foods    = new Map();
  room.newFoods = [];
  room.foodId   = 1;

  const gs = {
    players: new Map(),
    timeLeft: room.duration,
    tickCount: 0,
    overtime: false,
    zone: { x: 0, y: 0, w: WORLD_W, h: WORLD_H }, // 현재 존 경계 (시간이 지날수록 축소)
  };
  room.gs = gs;

  // 모든 로비 참가자 스폰
  for (const pinfo of room.players.values()) spawnGP(gs, pinfo);

  // 먹이 채우기 (왕거니 20% 포함)
  for (let i = 0; i < MAX_FOOD; i++) {
    const fx = Math.floor(Math.random() * (WORLD_W - 100) + 50);
    const fy = Math.floor(Math.random() * (WORLD_H - 100) + 50);
    if (Math.random() < 0.10) addFood(room, fx, fy, GROW_PER_FOOD * 8, null, true);
    else                      addFood(room, fx, fy, GROW_PER_FOOD,     null, false);
  }

  broadcastRoom(room, {
    type: 'gameStart',
    world: { w: WORLD_W, h: WORLD_H },
    duration: room.duration,
    zone: gs.zone,
    foods: Array.from(room.foods.values()),
    players: Array.from(gs.players.values()).map(serializeGP),
  });
  room.newFoods = [];

  room.gameLoop = setInterval(() => tickRoom(room), TICK_MS);
}

function spawnGP(gs, pinfo) {
  const ang = Math.random() * Math.PI * 2;
  const x   = 500 + Math.random() * (WORLD_W - 1000);
  const y   = 500 + Math.random() * (WORLD_H - 1000);
  gs.players.set(pinfo.id, {
    id: pinfo.id, ws: pinfo.ws, name: pinfo.name,
    color: randomColor(),
    x, y, angle: ang, targetAngle: ang,
    boosting: false,
    targetLen: 35, maxLen: 35,
    kills: 0,
    alive: true,
    segments: initSegments(x, y, ang, 35),
    invincibleTicks: 150,
  });
}

// ── 게임 틱 ──
function tickRoom(room) {
  const gs = room.gs;
  if (!gs) return;

  gs.tickCount++;

  // 1초마다 타이머 감소 (1000/45 ≈ 22.2 틱마다)
  if (gs.tickCount % Math.round(1000 / TICK_MS) === 0) {
    gs.timeLeft = Math.max(0, gs.timeLeft - 1);
    if (gs.timeLeft <= 0) {
      const aliveCount = Array.from(gs.players.values()).filter(p => p.alive).length;
      if (aliveCount <= 1) { endGame(room); return; }
      // 시간 초과지만 생존자 2명 이상 → 연장전 (1인 남을 때까지 계속)
      if (!gs.overtime) {
        gs.overtime = true;
        broadcastRoom(room, { type: 'overtime' });
      }
    }
  }

  // ── 존 축소 (timeLeft 기준으로 정확히 동기화) ──
  {
    const ZONE_FINAL_MARGIN = WORLD_W * 0.47; // 최종 여백 (각 방향 47%, 중앙 6%까지)
    const elapsed = room.duration - gs.timeLeft; // 경과 시간(초)
    const startSec = room.duration * 0.05;       // 5% 경과 후 시작
    if (elapsed > startSec) {
      const prog = Math.min(1, (elapsed - startSec) / (room.duration - startSec));
      // 틱 단위 보간: 1초 내에서 tickCount로 부드럽게
      const ticksPerSec = Math.round(1000 / TICK_MS);
      const tickInSec   = gs.tickCount % ticksPerSec;
      const progExtra   = tickInSec / ticksPerSec / room.duration;
      const smoothProg  = Math.min(1, prog + progExtra);
      const m = Math.round(ZONE_FINAL_MARGIN * smoothProg);
      gs.zone = { x: m, y: m, w: Math.max(20, WORLD_W - m * 2), h: Math.max(20, WORLD_H - m * 2) };
    }
  }

  for (const gp of gs.players.values()) {
    if (gp.alive) updateGP(room, gp);
  }
  checkCollisions(room, gs);
  fillRoomFood(room);
  sendState(room, gs);
}

function updateGP(room, p) {
  if (p.invincibleTicks > 0) p.invincibleTicks--;

  // 각도 보간
  let diff = p.targetAngle - p.angle;
  while (diff >  Math.PI) diff -= Math.PI * 2;
  while (diff < -Math.PI) diff += Math.PI * 2;
  p.angle += diff * 0.15;

  // 몸집이 클수록 빠름: 길이 35(기본) 기준 sqrt 스케일, 최소/최대 클램프
  const spdMult = Math.sqrt(p.targetLen / 35);
  const baseSpd  = Math.max(1.8, Math.min(BASE_SPD  * spdMult, 7.0));
  const boostSpd = Math.max(3.0, Math.min(BOOST_SPD * spdMult, 11.0));
  const spd = p.boosting ? boostSpd : baseSpd;
  p.x += Math.cos(p.angle) * spd;
  p.y += Math.sin(p.angle) * spd;

  // 존 경계 충돌 사망 (시간이 지날수록 좁아지는 존)
  const z = room.gs.zone;
  if (p.x < z.x + 12 || p.x > z.x + z.w - 12 || p.y < z.y + 12 || p.y > z.y + z.h - 12) {
    killGP(room, p, null); return;
  }

  p.segments.unshift({ x: p.x, y: p.y });
  if (p.segments.length > p.targetLen) p.segments.length = Math.floor(p.targetLen);

  if (p.boosting) {
    if (p.targetLen > 10) p.targetLen -= (TICK_MS / 1000);
    else                  p.boosting = false;
  }
  p.targetLen = Math.max(10, p.targetLen);
  if (p.targetLen > p.maxLen) p.maxLen = p.targetLen;

  // 먹이 먹기
  const hr         = headRadius(p);
  const eatRangeSq = (hr + 8) ** 2;
  for (const [fid, f] of room.foods) {
    const dx = p.x - f.x, dy = p.y - f.y;
    if (dx * dx + dy * dy < eatRangeSq) {
      p.targetLen += (f.value || GROW_PER_FOOD);
      room.foods.delete(fid);
      broadcastRoom(room, { type: 'foodEat', id: fid });
    }
  }
}

function checkCollisions(room, gs) {
  const alive = Array.from(gs.players.values()).filter(p => p.alive);
  for (const a of alive) {
    const hr = headRadius(a);

    // 자기 몸통 충돌 비활성화

    // 타 플레이어 몸통 충돌 (양쪽 중 하나라도 무적이면 스킵)
    for (const b of alive) {
      if (a.id === b.id) continue;
      if (a.invincibleTicks > 0 || b.invincibleTicks > 0) continue;
      const br = headRadius(b);
      for (let i = 0; i < b.segments.length; i += 2) {
        const s = b.segments[i];
        const dx = a.x - s.x, dy = a.y - s.y;
        if (dx * dx + dy * dy < (hr + br) ** 2) { killGP(room, a, b); break; }
      }
      if (!a.alive) break;
    }
  }
}

function killGP(room, victim, killer) {
  victim.alive = false;

  // 시체를 먹이로 변환
  for (let i = 0; i < victim.segments.length; i += 4) {
    const s = victim.segments[i];
    addFood(room,
      s.x + (Math.random() - 0.5) * 15,
      s.y + (Math.random() - 0.5) * 15,
      1, victim.color, false
    );
  }

  let killMsg = `💥 ${victim.name} 님이 사망했습니다.`;
  if (killer && killer.id !== victim.id) {
    killer.kills++;
    killMsg = `💀 ${killer.name} 님이 ${victim.name} 님을 처치했습니다!`;
  }

  broadcastRoom(room, {
    type: 'playerDied',
    id:      victim.id,
    killMsg,
    length:  Math.floor(victim.targetLen),
    kills:   victim.kills,
  });

  // 1명 이하 생존 시 게임 종료
  const aliveCount = Array.from(room.gs.players.values()).filter(p => p.alive).length;
  if (aliveCount <= 1) {
    // 0명 생존(동시 사망): 길이가 더 긴 플레이어를 승자로 처리
    if (aliveCount === 0) {
      const allPlayers = Array.from(room.gs.players.values());
      const longestPlayer = allPlayers.sort((a, b) => b.maxLen - a.maxLen)[0];
      if (longestPlayer) longestPlayer.alive = true; // 랭킹 1위 처리를 위해 임시로 생존 표시
    }
    setTimeout(() => endGame(room), 1500);
  }
}

function addFood(room, x, y, value, color, king) {
  const id = room.foodId++;
  const f  = { id, x: Math.round(x), y: Math.round(y), value, color: color || randomFoodColor(), king: !!king };
  room.foods.set(id, f);
  room.newFoods.push(f);
}

function fillRoomFood(room) {
  if (room.foods.size >= MAX_FOOD) return;
  const batch = Math.min(50, MAX_FOOD - room.foods.size);
  for (let i = 0; i < batch; i++) {
    const x = Math.floor(Math.random() * (WORLD_W - 100) + 50);
    const y = Math.floor(Math.random() * (WORLD_H - 100) + 50);
    if (Math.random() < 0.20) addFood(room, x, y, GROW_PER_FOOD * 8, null, true);
    else                      addFood(room, x, y, GROW_PER_FOOD,     null, false);
  }
}

function sendState(room, gs) {
  const alivePlayers = Array.from(gs.players.values()).filter(p => p.alive);
  const lb = [...alivePlayers]
    .sort((a, b) => b.targetLen - a.targetLen)
    .slice(0, 10)
    .map(p => ({ id: p.id, name: p.name, length: Math.floor(p.targetLen), color: p.color }));

  const msg = JSON.stringify({
    type: 'state',
    players:  alivePlayers.map(serializeGP),
    lb,
    newFoods: room.newFoods,
    timeLeft: gs.timeLeft,
    zone:     gs.zone,
  });
  room.newFoods = [];

  // 살아있는 플레이어 + 관전자(죽은 플레이어) 모두에게 전송
  for (const pinfo of room.players.values()) {
    if (pinfo.ws.readyState === WebSocket.OPEN) pinfo.ws.send(msg);
  }
}

function endGame(room) {
  if (room.gameLoop) { clearInterval(room.gameLoop); room.gameLoop = null; }
  room.phase = 'ended';

  const gs = room.gs;

  // 살아남은 플레이어 maxLen 최종 갱신
  for (const gp of gs.players.values()) {
    if (gp.alive && gp.targetLen > gp.maxLen) gp.maxLen = gp.targetLen;
  }

  // 랭킹: 생존자 우선, 나머지는 maxLen 내림차순
  const survivors = Array.from(gs.players.values()).filter(p => p.alive);
  const dead = Array.from(gs.players.values()).filter(p => !p.alive)
    .sort((a, b) => b.maxLen - a.maxLen || b.kills - a.kills);
  const ranking = [...survivors, ...dead].map((p, i) => ({
    rank:   i + 1,
    name:   p.name,
    length: Math.floor(p.maxLen),
    kills:  p.kills,
    color:  p.color,
  }));

  broadcastRoom(room, { type: 'gameOver', ranking });
}

// ═══════════════════════════════════════════════════
//  유틸
// ═══════════════════════════════════════════════════

function broadcastLobbyUpdate(room) {
  const players = Array.from(room.players.values())
    .map(p => ({ id: p.id, name: p.name, isTeacher: p.isTeacher }));
  broadcastRoom(room, { type: 'lobbyUpdate', players });
}

function headRadius(p) {
  // 길이가 커질수록 머리가 작아짐 (35 → 22, 길수록 → 최소 6)
  return Math.max(6, 22 - (p.targetLen - 35) * 0.075); // 서버 충돌 반지름
}

function initSegments(x, y, ang, count) {
  const s = [];
  for (let i = 0; i < count; i++)
    s.push({ x: x - Math.cos(ang) * i * SEG_GAP, y: y - Math.sin(ang) * i * SEG_GAP });
  return s;
}

function makeCode() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code;
  do { code = Array.from({ length: 4 }, () => chars[Math.floor(Math.random() * chars.length)]).join(''); }
  while (rooms.has(code));
  return code;
}

function randomColor() {
  return ['#22cc44','#0099bb','#ee2233','#cc8800','#aa22cc','#ee6600','#2255cc'][Math.floor(Math.random() * 7)];
}

function randomFoodColor() {
  return ['#ee4455','#dd9900','#33aa55','#2266dd','#cc33bb'][Math.floor(Math.random() * 5)];
}

function serializeGP(p) {
  const segs = [];
  for (let i = 0; i < p.segments.length; i++)
    segs.push({ x: Math.round(p.segments[i].x), y: Math.round(p.segments[i].y) });
  return {
    id: p.id, name: p.name, color: p.color,
    x: Math.round(p.x), y: Math.round(p.y), angle: p.angle,
    len: Math.floor(p.targetLen), kills: p.kills,
    alive: p.alive, boosting: p.boosting, invincible: p.invincibleTicks > 0,
    segments: segs,
  };
}

function send(ws, obj) {
  if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj));
}

function broadcastRoom(room, obj) {
  const raw = JSON.stringify(obj);
  for (const pinfo of room.players.values()) {
    if (pinfo.ws.readyState === WebSocket.OPEN) pinfo.ws.send(raw);
  }
}

// ── 서버 시작 ──
httpServer.listen(PORT, () => {
  const ifaces = os.networkInterfaces();
  const rows   = [{ 대상: '내 컴퓨터 (본인)', 주소: `http://localhost:${PORT}` }];
  const virtualRanges = ['192.168.56.', '192.168.99.', '192.168.159.', '192.168.230.'];
  for (const [name, iface] of Object.entries(ifaces)) {
    for (const info of iface) {
      if (info.family !== 'IPv4' || info.internal) continue;
      if (virtualRanges.some(r => info.address.startsWith(r))) continue;
      rows.push({ 대상: `🌐 ${name} (친구)`, 주소: `http://${info.address}:${PORT}` });
    }
  }
  console.log('\n  SNAKE.IO 서버 시작!\n');
  console.log(`  ⭐ 선생님 비밀번호: ${TEACHER_PW}\n`);
  console.table(rows);
  console.log('  서버를 끄려면 Ctrl+C\n');
});
